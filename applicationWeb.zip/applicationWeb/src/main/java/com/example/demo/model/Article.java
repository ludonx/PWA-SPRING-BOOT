package com.example.demo.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Article {

	
	private String name;
	private Long quantity;
	private String type;


	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Long getQuantity() {
		return quantity;
	}
	public void setQuantity(Long quantity) {
		this.quantity = quantity;
	}
	
	@Override
	  public String toString() {
	    return "Article{" +
	        "name= " + name + "\n" +
	        "quantity= " + quantity +
	        '}';
	  }
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
}
