package com.example.demo.model.automate;

import java.util.Date;





public class Automate {

	public Automate() {
	}
	public Automate(String type, Address address_installation, String emplacement,
			Coordinated coordinated, Date intervention_date, String note) {
		this.type = type;
		this.address_installation = address_installation;
		this.emplacement = emplacement;
		this.coordinated = coordinated;
		this.intervention_date = intervention_date;
		this.note = note;
	}
	
	private Long serial_number;
	private String type;
	private Address address_installation;
	
	private String emplacement;
	private Coordinated coordinated;
	
	private Date intervention_date;
	private String note;

	public Long getSerial_number() {
		return serial_number;
	}
	public void setSerial_number(Long serial_number) {
		this.serial_number = serial_number;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public Address getAddress_installation() {
		return address_installation;
	}
	public void setAddress_installation(Address address_installation) {
		this.address_installation = address_installation;
	}
	public String getEmplacement() {
		return emplacement;
	}
	public void setEmplacement(String emplacement) {
		this.emplacement = emplacement;
	}
	public Coordinated getCoordinated() {
		return coordinated;
	}
	public void setCoordinated(Coordinated coordinated) {
		this.coordinated = coordinated;
	}
	public Date getIntervention_date() {
		return intervention_date;
	}
	public void setIntervention_date(Date intervention_date) {
		this.intervention_date = intervention_date;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	
	
	
	

}
