package com.example.demo.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AutomateInformation {
	private String state;
	private Double temperature;
	
	private PaymentState  paymentState;
	
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public Double getTemperature() {
		return temperature;
	}
	public void setTemperature(Double temperature) {
		this.temperature = temperature;
	}

	public PaymentState getPaymentState() {
		return paymentState;
	}

	public void setPaymentState(PaymentState paymentState) {
		this.paymentState = paymentState;
	}
	
	@Override
	  public String toString() {
	    return "AutomateInformation{" +
	        "state= " + state + "\n" +
	        "temperature= " + temperature + "\n" +
	        "paymentState= " + paymentState + 
	        '}';
	  }
	

}
