package com.example.demo.model.weather;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


@JsonIgnoreProperties(ignoreUnknown = true)
public class Main {

	private Weather main;

	public Weather getMain() {
		return main;
	}

	public void setMain(Weather main) {
		this.main = main;
	}
	
}
