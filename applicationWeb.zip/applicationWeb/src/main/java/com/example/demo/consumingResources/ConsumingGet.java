package com.example.demo.consumingResources;



import java.net.URI;
import java.util.Collections;
import java.util.Date;
import java.util.List;


import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

import com.example.demo.model.DailyReport;
import com.example.demo.model.automate.Address;
import com.example.demo.model.automate.Automate;
import com.example.demo.model.automate.Coordinated;
import com.example.demo.model.weather.Main;

@Controller
public class ConsumingGet {
	
	public List<DailyReport> getApi(final String path, final HttpMethod method) {     
	    final RestTemplate restTemplate = new RestTemplate();
	    final ResponseEntity<List<DailyReport>> response = restTemplate.exchange(
	      path,
	      method,
	      null,
	      new ParameterizedTypeReference<List<DailyReport>>(){});
	    List<DailyReport> list = response.getBody();
	    return list;
	}
	
	public List<Automate> getApiAutomate(final String path, final HttpMethod method) {     
	    final RestTemplate restTemplate = new RestTemplate();
	    final ResponseEntity<List<Automate>> response = restTemplate.exchange(
	      path,
	      method,
	      null,
	      new ParameterizedTypeReference<List<Automate>>(){});
	    List<Automate> list = response.getBody();
	    return list;
	}
	
	@GetMapping("/printJson")
	public String getJson(Model model) throws Exception {
		// Create a new RestTemplate instance

		// Add the Jackson message converter

		// Make the HTTP GET request, marshaling the response from JSON to an array of Events
		List<DailyReport> reports = this.getApi("http://localhost:8080/pwa/services/dailyReport/all",HttpMethod.GET);
		Collections.sort(reports, (d1, d2) -> {
			return (int) (d2.getIncome() - d1.getIncome());
		});
		model.addAttribute("reports", reports);
		
		List<Automate> automates = this.getApiAutomate("http://localhost:8080/pwa/services/automate/all", HttpMethod.GET);
		int size = automates.size();
		float meteo[];
		if(size != 0) {
			Automate last = automates.get(size - 1);
			size = last.getSerial_number().intValue();
			meteo= new float[size];
		}
		else {
			meteo = new float[1];		
		}
		int i;
		String city;
		String country;
		
		for(Automate automate: automates) {
			city = automate.getAddress_installation().getCity();
			country = automate.getAddress_installation().getState();
			RestTemplate restTemplate = new RestTemplate();
			Main main = restTemplate.getForObject(
					"http://api.openweathermap.org/data/2.5/weather?units=metric&lang=fr&appid=0ec1f169aa0bd928c48011d06b3bca2b&q="+city+","+country+"", Main.class);
			meteo[automate.getSerial_number().intValue() - 1] = main.getMain().getTemp();
		}
		model.addAttribute("meteo", meteo);
		
		return "printJson";
	}
	
	@GetMapping("/printAutomates")
	public String getAutomates(Model model) throws Exception {

		// Make the HTTP GET request, marshaling the response from JSON to an array of Events
		List<Automate> automates  = this.getApiAutomate("http://localhost:8080/pwa/services/automate/all", HttpMethod.GET);
		
		model.addAttribute("automates", automates);
		return "printAutomates";
	}
	
	@GetMapping(path= "/addAutomate")
	public void addAutomate(@RequestParam(name="type", required=false, defaultValue="Null") String type, 
										  @RequestParam(name="street_number", required=false, defaultValue="0") long street_number,
										  @RequestParam(name="street_description", required=false, defaultValue="Null") String street_description, 
										  @RequestParam(name="city", required=false, defaultValue="Null") String city, 
										  @RequestParam(name="state",required=false, defaultValue="Null") String state, 
										  @RequestParam(name="emplacement", required=false, defaultValue="Null") String emplacement, 
										  @RequestParam(name="longitude", required=false, defaultValue="0") long longitude, 
										  @RequestParam(name="latitude", required=false, defaultValue="0") long latitude, 
										  @RequestParam(name="note", required=false, defaultValue="Null") String note, 
										  Model model) throws Exception 
	{  
		if(type.equals("Null")) {
			int added = 0;
		    model.addAttribute("added", added);
		}
		else {
		    RestTemplate restTemplate = new RestTemplate();
		    final String baseUrl = "http://localhost:8080/pwa/services/automate/add";
		    URI uri = new URI(baseUrl);
		    
		    Address addresse = new Address(street_number, street_description, city, state);
		    Coordinated coordonnee = new Coordinated(longitude,latitude);
		    Date intervention_date = new Date();
		    Automate automate = new Automate(type, addresse, emplacement, coordonnee, intervention_date , note);
	
		    restTemplate.postForEntity(uri, automate, String.class);
			int added = 1;
		    model.addAttribute("added", added);		    
		}
	}

	
	@GetMapping(path= "/delete")	
	public void deleteAutomate(@RequestParam(name="id", required=false, defaultValue="-1") int id, Model model)
	{
		if(id == -1) {
			int deleted = 0;
		    model.addAttribute("deleted", deleted);
		}
		else {
		    final String uri = "http://localhost:8080/pwa/services/automate/delete/"+id;	     
		    RestTemplate restTemplate = new RestTemplate();
		    restTemplate.delete ( uri);
		    int deleted = 1;
		    model.addAttribute("deleted", deleted);
		}
	}


}
