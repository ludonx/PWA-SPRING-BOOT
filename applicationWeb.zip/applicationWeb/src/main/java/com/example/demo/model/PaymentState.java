package com.example.demo.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PaymentState {
	private String coins;
	private String smart_card;
	private String card;
	
	public String getCoins() {
		return coins;
	}
	public void setCoins(String coins) {
		this.coins = coins;
	}
	public String getSmart_card() {
		return smart_card;
	}
	public void setSmart_card(String smart_card) {
		this.smart_card = smart_card;
	}
	public String getCard() {
		return card;
	}
	public void setCard(String card) {
		this.card = card;
	}
	
	@Override
	  public String toString() {
	    return "PaymentState{" +
	        "coins= " + coins + "\n" +
	        "smart_card= " + smart_card + "\n" +
	        "card= " + card + 
	        '}';
	  }
	
	
}
